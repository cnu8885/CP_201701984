
public class Student {
	private String name;
	private String major;
	private int StudentNum; // �й�
	private int grade; // �г�
	private int score; // �̼�����

	// ������
	public Student() {
		name = "��μ�";
		major = "��ǻ�Ͱ��а�";
		StudentNum = 201701984;
		grade = 1;
		score = 33;
	}

	// ������
	public void setStudent(String n, String m, int st, int g, int sc) {
		name = n;
		major = m;
		StudentNum = st;
		grade = g;
		score = sc;
	}

	public String getName() {
		return name;
	}

	public String getMajor() {
		return major;
	}

	public int getStudentNum() {
		return StudentNum;
	}

	public int getGrade() {
		return grade;
	}

	public int getScore() {
		return score;
	}

	public String toString() {
		return "�̸� : " + name + ", �а� : " + major + ", �й� : " + StudentNum + ", �г� : " + grade + ", �̼����� : " + score;
	}
}

class UnderGraduate extends Student {
	private String club;

	public UnderGraduate() {
		club = "Grow";
	}

	public void setClub(String c) {
		club = c;
	}

	public String getClub() {
		return club;
	}

	public String toString() {
		return super.toString() + ", ���Ƹ���  : " + club;
	}
}

class Graduate extends Student {
	private String assistant;
	private double scholarship;

	public Graduate() {
		assistant = "���� ����";
		scholarship = 0.3;
	}

	public void setGraduate(String a, double s) {
		assistant = a;
		scholarship = s;
	}

	public String getAssistant() {
		return assistant;
	}

	public double getScholarship() {
		return scholarship;
	}
	
	public String toString() {
		return super.toString() + ", ���� ���� : " + assistant + ", ���б� ���� : " + scholarship;
	}
}