
public abstract class Shape {
	protected int width, height;
	
	public Shape(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	public abstract int area();
	
}

class Triangle extends Shape {
	
	public Triangle(int width, int height) {
		super(width, height);
	}
	
	public int area() {
		return (width * height) / 2;
	}
}

class Rectangle extends Shape {
	
	public Rectangle(int width, int height) {
		super(width, height);
	}
	
	public int area() {
		return width * height;
	}
}

class Circle extends Shape {	
	private int radius;
	
	public Circle(int width, int height, int radius) {
		super(width, height);
		this.radius = radius;
	}
	
	public int area() {
		final double PI = Math.PI;
		return (int) (radius * radius * PI);
	}
}