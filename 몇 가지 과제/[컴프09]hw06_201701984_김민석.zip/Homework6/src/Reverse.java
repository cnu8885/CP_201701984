public class Reverse {
	
	public void startReverse(String a) {
		for (int i = a.length() - 1; i >= 0; i--) {
			System.out.print(a.charAt(i));
		}
	}
}