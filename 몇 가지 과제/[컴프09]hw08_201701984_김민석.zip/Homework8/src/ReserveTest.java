public class ReserveTest {

	public static void main(String[] args) {
		Reserve a = new Reserve();
		a.newReserve();
	}

}
